<?php
	$loginpassword = 'xxx';

	$hostname = "mysql.xxx.com"; // the hostname you created when creating the database
	$username = "xxx";      // the username specified when setting up the database
	$password = "xxx";      // the password specified when setting up the database
	$database = "xxx";      // the database name chosen when setting up the database 
?>
